#!/bin/bash
# Programa para declarar dos variables (option y result)
option="Primera variable"
result="Segunda variable"

echo "Option: $option y Resutt: $result"
