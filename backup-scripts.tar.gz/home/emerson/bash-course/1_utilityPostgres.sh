#!/bin/bash
# Programa para realizar algunar operaciones utilitarios de Postgres

echo "Hola bienvenido al curso de programación bash"
