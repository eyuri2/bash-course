#!/bin/bash
# Programa para ejemplificar el uso de la descarga de información desde internet utilizando el comando wget

echo "Descargar información de internet"
wget https://downloads.apache.org/tomcat/tomcat-8/v8.5.54/bin/apache-tomcat-8.5.54.zip
