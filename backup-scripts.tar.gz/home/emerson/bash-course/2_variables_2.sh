#!/bin/bash
# Programa para revisar la declaración de variables

echo "Opción nombre pasada del script anterior: $nombre"
